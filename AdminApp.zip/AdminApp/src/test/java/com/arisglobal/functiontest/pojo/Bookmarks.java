package com.arisglobal.functiontest.pojo;

import lombok.Value;

@Value
public class Bookmarks {
    String fieldName;
    String fieldId;
}
