package com.arisglobal.functiontest.helper;

public enum Context {
    RESPONSE,
    RESPONSE_BODY,
    RESPONSE_STATUS,
    SCENARIO,
    TOKEN
}
