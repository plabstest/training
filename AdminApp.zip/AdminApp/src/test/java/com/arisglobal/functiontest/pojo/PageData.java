package com.arisglobal.functiontest.pojo;

import lombok.Data;

@Data
public class PageData {
    String ruleName;
    String description;
    String activeYN;
    String ruleType;
    String ruleID;
    String systemRuleYN;
    String ruleStatus;
    String sequence;

}
