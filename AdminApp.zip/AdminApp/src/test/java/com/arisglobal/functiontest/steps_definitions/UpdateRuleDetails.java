package com.arisglobal.functiontest.steps_definitions;

import com.arisglobal.functiontest.helper.ApiHelper;
import com.arisglobal.functiontest.pojo.*;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import net.sf.json.JSONObject;


import static com.arisglobal.functiontest.hooks.Hooks.scenarioContext;
import static com.arisglobal.functiontest.utils.TestDataUtils.*;
import static com.arisglobal.functiontest.utils.TestUtils.getFileContent;
import static net.sf.json.JSONObject.fromObject;
import static org.junit.Assert.assertEquals;

public class UpdateRuleDetails {
    final String randomRulCreate = CreateRule.randomRule;

    @When("I update the Conditions and Expression for the Rule {string}, {string} and {string}")
    public void iUpdateTheConditionsAndExpressionForTheRuleAnd(String ruleID, String ruleName, String moduleName) {
        String request = getFileContent(GET_RULEDETAILS_PATH).replace("RuleConditions", getFileContent(CONDITION_PATH)).
                replace("RuleCheck35", ruleID).replace("RuleCheck35", ruleName).replace("ModuleName", moduleName);
        ApiHelper.sendPutRequestWithHeadersToApp(LSMV_ADMIN_RULE_URL, fromObject(request));
    }

    @When("I update the rule {string} for the Field {string} as {string}")
    public void iUpdateTheRuleForTheFieldAs(String ruleID, String fieldName, String fieldValue) {
        String recordID = iGetFieldValueAs("recordId");
        if (ruleID.equals("CreatedRule"))
            ruleID = randomRulCreate;
        JSONObject jsObj = fromObject(getFileContent(GET_RULEDETAILS_PATH).replace("RuleCheck35", ruleID).replace("240811", recordID));
        jsObj.replace("ruleConditions", getFileContent(CONDITION_PATH));
        jsObj.replace(fieldName, fieldValue);
        ApiHelper.sendPutRequestWithHeadersToApp(LSMV_ADMIN_RULE_URL, jsObj);
    }

    @When("I update the rule {string} for the Field {string} as {string} for AutoCalculations")
    public void iUpdateAutoTheRuleForTheFieldAs(String ruleID, String fieldName, String fieldValue) {
        String recordID = iGetFieldValueAs("recordId");
        if (ruleID.equals("CreatedRule"))
            ruleID = randomRulCreate;
        JSONObject jsObj = fromObject(getFileContent(GET_RULEDETAILS_AutoCALPATH).replace("RuleCheck35", ruleID).replace("240811", recordID));
        jsObj.replace("ruleConditions", getFileContent(CONDITION_PATH));
        jsObj.replace(fieldName, fieldValue);
        ApiHelper.sendPutRequestWithHeadersToApp(LSMV_ADMIN_RULE_URL, jsObj);
    }

    @And("response contains update rule details Condition, {string},{string},{string},{string},{string}")
    public void responseContainsUpdateRuleDetails(String ruleID, String ruleName, String ruleDesc, String ruleType, String moduleName) {
        Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        CreateRuleResponse getRulesResponse = response.as(CreateRuleResponse.class);
        assertEquals(ruleName, getRulesResponse.getRuleName());
        assertEquals(ruleDesc, getRulesResponse.getDescription());
        assertEquals(ruleType, getRulesResponse.getRuleType());
        assertEquals(moduleName, getRulesResponse.getModuleName());
        assertEquals(fromObject(getFileContent(CONDITION_PATH)), getRulesResponse.getRuleConditions());
    }

    @Then("response contains {string} is {string} for RuleCondition in RuleId {string}")
    public void responseContainsIsForRuleConditionInRuleId(String fieldName, String fieldValue, String ruleID) {
        Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        CreateRuleResponse getRulesResponse = response.as(CreateRuleResponse.class);
        assertEquals("Y", getRulesResponse.getRuleConditions().get(0).getPrevCaseYN());
        assertEquals("Y", getRulesResponse.getRuleConditions().get(0).getRhsFlPrevCaseYN());
        assertEquals("N", getRulesResponse.getRuleConditions().get(1).getPrevCaseYN());
        assertEquals("N", getRulesResponse.getRuleConditions().get(1).getRhsFlPrevCaseYN());
    }

    @When("response contains {string} is {string} for rule {string}")
    public void responseContainsIsForRule(String FieldName, String FieldValue, String ruleID) {
        Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        CreateRuleResponse getRulesResponse = response.as(CreateRuleResponse.class);
        assertEquals("FieldValue", getRulesResponse.getSameContextYN());
    }

    //===========ActionItems=========
    @Then("Verify the response of actionDefinitionJsonResource {string} for functionType {string}")
    public void verifyTheResponseOfActionDefinitionJsonResource(String resourse,String functionType) {
        JSONObject jsObj = null;
        int Resource = Integer.parseInt(resourse);
        if(functionType.equals("Conversions"))
            jsObj = fromObject(getFileContent(GET_DATEUNIT_CONVERSION_PATH));
        else if(functionType.equals("Calculations"))
            jsObj = fromObject(getFileContent(GET_ACTIONITEMS_PATH));
        String expectedActionDefinition = jsObj.getJSONArray("actionItems").getJSONObject(Resource).toString();
         Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        String res = response.asString();
        JsonObject json = JsonParser.parseString(res).getAsJsonObject();
        String actualJsonArray = json.getAsJsonObject("ruleExpression").getAsJsonArray("actionItems").get(0).getAsJsonObject().toString();
        assertEquals(expectedActionDefinition, actualJsonArray);
    }
    @Then("verify the response of actionDefinitionJson {string}")
    public void verifyTheResponseOfActionDefinitionJson(String expectedJson) {
        if (expectedJson.equalsIgnoreCase("ExpectedResult")) {
            JSONObject jsObj = fromObject(getFileContent(UPDATE_RULEDETAILS_PATH));
            String expectedJsonArry = jsObj.getJSONObject("ruleExpression").getJSONArray("actionItems").get(0).toString();
            expectedJson = expectedJsonArry;
        }
        Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        String res = response.asString();
        JsonObject json = JsonParser.parseString(res).getAsJsonObject();
        String actualJsonArray = json.getAsJsonObject("ruleExpression").getAsJsonArray("actionItems").get(0).getAsJsonObject().getAsJsonObject("actionDefinitionJson").toString();
        assertEquals(expectedJson, actualJsonArray);
    }

    @And("Check the response matches with expected Action items")
    public void checkTheResponseMatchesWithExpectedActionItems() {
        JSONObject jsObj = fromObject(getFileContent(UPDATE_RULEDETAILS_PATH));
        String expectedJsonArray = jsObj.getJSONObject("ruleExpression").getJSONArray("actionItems").toString();
        Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        String res = response.asString();
        JsonObject json = JsonParser.parseString(res).getAsJsonObject();
        String actualJsonArray = json.getAsJsonObject("ruleExpression").getAsJsonArray("actionItems").toString();
        assertEquals(expectedJsonArray, actualJsonArray);
    }

    @When("I update the action type to {string} and Severity {string} for RuleID {string}")
    public void iUpdateTheActionTypeToAndSeverityForRuleID(String actionType, String severity, String ruleID) {
        String recordID = iGetFieldValueAs("recordId");
        String request = getFileContent(UPDATE_RULEDETAILS_PATH).replace("RuleCheck35", ruleID).replace("Validation", actionType).replace("ERROR", severity);
        ApiHelper.sendPutRequestWithHeadersToApp(LSMV_ADMIN_RULE_URL, fromObject(request.replace("RecordID", recordID)));
    }

    @When("I update the rule for bookmark & pointToField & valMessages and Severity for ruleID {string},modulename as {string}")
    public void iUpdateTheRuleForBookmarkPointToFieldValMessagesAndSeverityForRuleIDModulename(String ruleID, String moduleName) {
        //JSONObject request = fromObject(getFileContent(UPDATE_RULEDETAILS_PATH).replace("ModuleName",moduleName).replace("RuleCheck35",ruleID));
        String recordID = iGetFieldValueAs("recordId");
        ApiHelper.sendPutRequestWithHeadersToApp(LSMV_ADMIN_RULE_URL, fromObject(getFileContent(UPDATE_RULEDETAILS_PATH).replace("RecordID", recordID).replace("ModuleName", moduleName).replace("RuleCheck35", randomRulCreate)));
    }

    public String iGetFieldValueAs(String fieldName) {
        Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        String res = response.asString();
        JsonObject jsonObj = JsonParser.parseString(res).getAsJsonObject();
        String FieldValue = jsonObj.get(fieldName).toString();
        System.out.println(FieldValue);
        return FieldValue;
    }

    @When("I update the actionItems for rule {string} for moduleName as {string}, functionType as {string} and actionDefinitionJson {string}")
    public void iUpdateTheRuleActionItemsWith(String ruleID,String moduleName,String functionType, String actionDefinitionResource) {
        JSONObject jsObj = null;
        if (ruleID.equals("CreatedRule"))
            ruleID = randomRulCreate;
        if(functionType.equals("Conversions"))
             jsObj = fromObject(getFileContent(GET_DATEUNIT_CONVERSION_PATH));
        else if(functionType.equals("Calculations"))
             jsObj = fromObject(getFileContent(GET_ACTIONITEMS_PATH));
        int Resource = Integer.parseInt(actionDefinitionResource);
        String actualActionDefinition = jsObj.getJSONArray("actionItems").getJSONObject(Resource).get("actionDefinitionJson").toString();
        String recordID = iGetFieldValueAs("recordId");
        JSONObject jsObjActual = fromObject(getFileContent(UPDATE_RULEDETAILS_PATH).replace("RecordID", recordID).replace("ModuleName", moduleName).replace("RuleCheck35", randomRulCreate));
        JSONObject jsActionItem = jsObjActual.getJSONObject("ruleExpression").getJSONArray("actionItems").getJSONObject(0);
        jsActionItem.replace("actionDefinitionJson", actualActionDefinition);
        jsActionItem.replace("actionType", moduleName);
        System.out.println(jsObjActual.toString());
        ApiHelper.sendPutRequestWithHeadersToApp(LSMV_ADMIN_RULE_URL, jsObjActual);
    }

    @Then("response contains rule with actionDefination as {string}")
    public void responseContainsRuleWithActionDefinationAs(String expected) {
        JSONObject jsObj = fromObject(getFileContent(GET_ACTIONITEMS_PATH));
        String expectedActionDefinition = jsObj.getJSONArray("actionItems").getJSONObject(0).get("actionDefinitionJson").toString();

        Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        CreateRuleResponse getRulesResponse = response.as(CreateRuleResponse.class);
        String actualActionDefinationJson = getRulesResponse.getRuleExpression().getActionItems().get(0).getActionDefinitionJson();
        assertEquals(expectedActionDefinition, actualActionDefinationJson);
    }
}

