package com.arisglobal.functiontest.steps_definitions;

import com.arisglobal.functiontest.helper.ApiHelper;
import com.arisglobal.functiontest.helper.ApiHelperForNeg;
import com.arisglobal.functiontest.pojo.CreateRuleResponse;
import com.arisglobal.functiontest.pojo.FilterRuleResponse;
import com.arisglobal.functiontest.pojo.PageData;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import net.sf.json.JSONObject;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import static com.arisglobal.functiontest.hooks.Hooks.scenarioContext;
import static com.arisglobal.functiontest.utils.TestDataUtils.*;
import static com.arisglobal.functiontest.utils.TestUtils.getFileContent;
import static net.sf.json.JSONObject.fromObject;
import static org.junit.Assert.assertEquals;

public class GetRulesByFilter {
    final String randomCreateRule = CreateRule.randomRule;
    static String randomRule;

    @And("check the response contains {string}, {string}, {string}, {string}, {string}")
    public void checkTheResponseContains(String ruleID, String ruleName, String ruleDesc, String ruleType, String moduleName) {
        Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        CreateRuleResponse getRulesResponse = response.as(CreateRuleResponse.class);
        assertEquals(randomCreateRule, getRulesResponse.getRuleID());
        assertEquals(ruleName + "_name", getRulesResponse.getRuleName());
        assertEquals(ruleDesc + "_desc", getRulesResponse.getDescription());
        assertEquals(moduleName, getRulesResponse.getModuleName());
        assertEquals(ruleType, getRulesResponse.getRuleType());
    }

    @Then("Response contains ruleIDs {string}")
    public void responseContains(List<Map<String, String>> expectedDataTable) {
        String expectedRuleName = expectedDataTable.get(0).get("ruleName");
        String expectedRuleID = expectedDataTable.get(0).get("ruleID");
        String expectedSequence = expectedDataTable.get(0).get("sequence");
        String[] ruleIdList = new String[0];
        if (expectedRuleID.equals("CreatedRule"))
            expectedRuleID = randomCreateRule;
        Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        FilterRuleResponse getRulesResponse = response.as(FilterRuleResponse.class);
        int PageRuleSize = getRulesResponse.getPageData().size();
        if (expectedRuleID.contains(",")) {
            ruleIdList = expectedRuleID.split(",");
            int expectedRuleIDSize = ruleIdList.length - 1;
            for (PageData eachList : getRulesResponse.getPageData()) {
                if (ruleIdList[expectedRuleIDSize].equals(eachList.getRuleID())) {
                    assertEquals(ruleIdList[expectedRuleIDSize], eachList.getRuleID());
                    --expectedRuleIDSize;
                    if (expectedRuleIDSize < 0)
                        break;
                } else
                    --PageRuleSize;
            }
        } else
            for (PageData eachList : getRulesResponse.getPageData()) {
                if (expectedRuleID.equals(eachList.getRuleID())) {
                    assertEquals(expectedRuleID, eachList.getRuleID());
                    assertEquals(expectedRuleName, eachList.getRuleName());
                    assertEquals(expectedSequence, eachList.getSequence());
                } else
                    --PageRuleSize;
            }
    }

    @Then("Response contains for search string ruleName {string},ruleID {string}, sequence {string}")
    public void responseContainsSearchString(String ruleName, String ruleID, String sequence) {
        String[] ruleIdList = new String[0];
        if (sequence.equals(""))
            sequence = null;
        if (ruleID.equals("CreatedRule"))
            ruleID = randomCreateRule;
        Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        FilterRuleResponse getRulesResponse = response.as(FilterRuleResponse.class);
        int PageRuleSize = getRulesResponse.getPageData().size();
        for (PageData eachList : getRulesResponse.getPageData()) {
            if (ruleID.equals(eachList.getRuleID())) {
                assertEquals(ruleID, eachList.getRuleID());
                assertEquals(ruleName, eachList.getRuleName());
                assertEquals(sequence, eachList.getSequence());
            } else
                --PageRuleSize;
        }
    }


    @Then("Verify the response contains ruleIDs {string}, fieldName {string} fieldValue {string}")
    public void responseContains(String ruleID, String fieldName, String fieldValue) {
        if (ruleID.equals("CreatedRule"))
            ruleID = randomCreateRule;
        Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        String res = response.asString();
        JsonObject jsonObj = JsonParser.parseString(res).getAsJsonObject();
        JsonArray PageDataArray = jsonObj.getAsJsonArray("pageData");
        for (int i = 0; i < PageDataArray.size(); i++) {
            JsonObject FilteredJsonObj = PageDataArray.get(i).getAsJsonObject();
            String actualRuleID = FilteredJsonObj.get("ruleID").toString();
            if (ruleID.equals(actualRuleID)) {
                assertEquals(fieldValue, FilteredJsonObj.get(fieldName).toString());
                break;
            }
        }
    }

    @When("I Filter rule for invalid {string}")
    public void iFilterRuleForInvalid(String invalidField) {
        ApiHelperForNeg.sendPostRequestToAPIForInvalidType(LSMV_ADMIN_FILTER_RULES, fromObject(getFileContent(GET_FILTERRULE_PATH)), invalidField);
    }

    @When("I filter rules for {string},{string},{string},{string},{string},{string},{string},{string},{string},{string}")
    public void iFilterRulesFor(String pageIndex, String recordsPerPage, String sortField, String sortOrder, String
            searchText, String moduleName, String ruleType, String active, String standard, String frozen) {
        ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_FILTER_RULES, fromObject(getFileContent(GET_FILTERRULE_PATH).
                replace("PageIndex", pageIndex).replace("RecordsPerPage", recordsPerPage).replace("SortField", sortField).replace("SortOrder", sortOrder).replace("SearchText", searchText).replace("ModuleName", moduleName).replace("RuleType", ruleType).
                replace("Active", active).replace("Standard", standard).replace("Frozen", frozen)));
    }

}

