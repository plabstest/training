package com.arisglobal.functiontest.steps_definitions;

import com.arisglobal.functiontest.helper.ApiHelper;
import com.arisglobal.functiontest.helper.ApiHelperForNeg;
import com.arisglobal.functiontest.pojo.CreateRuleResponse;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import net.sf.json.test.JSONAssert;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import static com.arisglobal.functiontest.hooks.Hooks.scenarioContext;
import static com.arisglobal.functiontest.utils.TestDataUtils.*;
import static com.arisglobal.functiontest.utils.TestUtils.getFileContent;
import static net.sf.json.JSONObject.fromObject;
import static org.junit.Assert.assertEquals;

public class SMQ_CMQLibrary {

    @When("I get all SMQ-CMQ library details with Search Criteria {string}")
    public void iGetAllSMQCMQLibraryDetails(String searchCriteria) {
        String smqCmqRegExpression = null;
        if (searchCriteria.equals(""))
            smqCmqRegExpression = null;
        else if (searchCriteria.equals("contains O"))
        smqCmqRegExpression = "%O%";
        else if (searchCriteria.equals("Starts with O"))
        smqCmqRegExpression = "O%25";
        else if (searchCriteria.equals("ends with O"))
            smqCmqRegExpression = "%25O";
        else if (searchCriteria.equals("Starts with 2"))
            smqCmqRegExpression = "2%25";
        ApiHelper.sendGetRequestToApp(String.format(SERVICE_URLL + "codingBrowser/getSmqCmqList?qname=" + smqCmqRegExpression + "&meddraVersion=v.25.1&type=SMQ"));
    }

    @Then("response contains the expected SMQ-CMQ Library")
    public void responseContainsTheExpectedSMQCMQLibrary() {
        JSONAssert.assertJsonEquals(fromObject(getFileContent(Response_All_SMQCMQLIB_PATH)).toString(),
                scenarioContext.getScenarioVariables().get("RESPONSE_BODY").toString());
    }
}
