package com.arisglobal.functiontest.pojo;

import lombok.Value;

import java.util.List;

@Value
public class RuleExpression {
    String recordId;
    String operator;
    String parentExpId;
    String refRuleConditionId;
    String refRuleId;
    String refRuleName;
    List<ActionItems> actionItems;
    List<ChildCondition> childConditions;
    List<ChildExpression> childExpressions;
}
