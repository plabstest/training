package com.arisglobal.functiontest.helper;

import com.arisglobal.functiontest.pojo.AuthenticationResponse;
import io.restassured.response.Response;
import static com.arisglobal.functiontest.helper.Context.TOKEN;
import static com.arisglobal.functiontest.hooks.Hooks.scenarioContext;
import static com.arisglobal.functiontest.utils.TestDataUtils.*;
import static com.arisglobal.functiontest.utils.TestUtils.getFileContent;
import static net.sf.json.JSONObject.fromObject;

public class GenerateToken {
    public static void getToken() {
        ApiHelper.sendPostRequestWithHeadersToApp(GET_TOKEN_URLI, fromObject(getFileContent(GET_TOKEN_BODY_PATH)));
        Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        AuthenticationResponse authenticationResponse = response.as(AuthenticationResponse.class);
        scenarioContext.setVariable(TOKEN, authenticationResponse.getAccess_token());
    }
}