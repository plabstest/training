package com.arisglobal.functiontest.steps_definitions;

import com.arisglobal.functiontest.helper.ApiHelper;
import com.arisglobal.functiontest.helper.ApiHelperForNeg;
import io.cucumber.java.en.When;
import net.sf.json.JSONObject;

import static com.arisglobal.functiontest.hooks.Hooks.scenarioContext;
import static com.arisglobal.functiontest.utils.TestDataUtils.*;
import static com.arisglobal.functiontest.utils.TestUtils.getFileContent;
import static net.sf.json.JSONObject.fromObject;

public class RuleConditions {
    @When("I Get Condition Display Text of {string}")
    public void getConditionDisplayTextOf(String ruleConditionsType) {
        JSONObject jsObj  =  fromObject(getFileContent(REFRULE_BODY_PATH));
        if(ruleConditionsType.equals("Simple RuleConditions"))
            ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_CONDITION_TEXT, fromObject(getFileContent(RULECOND_BODY_PATH)));
  else if(ruleConditionsType.equals("Reference rule"))
            ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_CONDITION_TEXT, fromObject(getFileContent(REFRULE_BODY_PATH)));
    else if(ruleConditionsType.equals("Invalid reference rule"))
        {
            jsObj.getJSONObject("newCondition").put("referenceRuleID", "BINGO");
            ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_CONDITION_TEXT, jsObj);
        }
    }

    @When("Get Condition Display Text of Filter RuleConditions and flagToAddedUICode to {string}")
    public void getConditionDisplayTextOfFilterRuleConditionsAndFlagToAddedUICodeTo(String flagToAddedUICode) {
        JSONObject jsObj  =  fromObject(getFileContent(FILTER_RULECONDITION_BODY_PATH));
        if(flagToAddedUICode.equals("false"))
        ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_CONDITION_TEXT,jsObj);
    else if(flagToAddedUICode.equals("true"))
            jsObj.replace("flagToAddedUICode",flagToAddedUICode);
        ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_CONDITION_TEXT,jsObj);
    }

    @When("Get Condition Display Text of priority over Reference rule and Rule Condition")
    public void getConditionDisplayTextOfPriorityOverReferenceRuleAndRuleCondition() {
        ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_CONDITION_TEXT, fromObject(getFileContent(REFRULE_RULECOND_PRIORITY_BODY_PATH)));
    }

    @When("Get Condition Display Text of Cyclic dependency {string}")
    public void getConditionDisplayTextOfCyclicDependency(String ruleConditionSet) {
        if(ruleConditionSet.equals("Of reference rule"))
        ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_CONDITION_TEXT, fromObject(getFileContent(CYCLIC_DEPENDENCY_REFERENCE_BODY_PATH)));
   else if(ruleConditionSet.equals("over RuleCondition"))
        ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_CONDITION_TEXT, fromObject(getFileContent(CYCLIC_DEPENDENCY_RULECONDITION_BODY_PATH)));
    }

    @When("Get Condition Display Text of passing {string}")
    public void getConditionDisplayTextOfPassing(String SetValues) {
        JSONObject jsObj = fromObject(getFileContent(RULECOND_BODY_PATH));
        if (SetValues.equals("LHS&Operator")) {
            jsObj.getJSONObject("newCondition").put("rhsFunc", "");
            jsObj.getJSONObject("newCondition").put("rhsConst", "");
            ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_CONDITION_TEXT, jsObj);
        } else if (SetValues.equals("RHS")) {
            jsObj.getJSONObject("newCondition").put("lhsFunc", "");
            jsObj.getJSONObject("newCondition").put("lhsFieldString", "");
            jsObj.getJSONObject("newCondition").put("operator", "");
            ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_CONDITION_TEXT, jsObj);
        }
    }

    @When("I Get Condition Display Text for invalid {string}")
    public void iGetConditionDisplayTextForInvalid(String invalidField) {
        ApiHelperForNeg.sendPostRequestToAPIForInvalidType(LSMV_ADMIN_CONDITION_TEXT, fromObject(getFileContent(RULECOND_BODY_PATH)), invalidField);
    }
}
