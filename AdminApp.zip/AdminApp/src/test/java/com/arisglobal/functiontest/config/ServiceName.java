package com.arisglobal.functiontest.config;

import static com.arisglobal.functiontest.utils.TestUtils.getEnvOrDefault;

public class ServiceName {
    public static ConfigFileReader configFileReader = new ConfigFileReader();
   // public static final String SERVICE_URLL = getEnvOrDefault("SERVICE_URL", configFileReader.getProperty("environmentApi")+ "lsmv-admin-service/");
}