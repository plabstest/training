package com.arisglobal.functiontest.steps_definitions;

import com.arisglobal.functiontest.helper.ApiHelper;
import com.arisglobal.functiontest.helper.ApiHelperForNeg;
import com.arisglobal.functiontest.pojo.CreateRuleResponse;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import net.sf.json.JSONObject;
import net.sf.json.JSONArray;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import static com.arisglobal.functiontest.hooks.Hooks.scenarioContext;
import static com.arisglobal.functiontest.utils.TestDataUtils.*;
import static com.arisglobal.functiontest.utils.TestUtils.getFileContent;
import static net.sf.json.JSONObject.fromObject;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertEquals;

public class FreezeRule {
    final String randomRulCreate = CreateRule.randomRule;

    @When("I freeze rule details by rule ID {string} and publishSummary {string}")
    public void iFreezeRuleWithRuleID(String ruleID, String publishSummary) {
        if (ruleID.equals("CreatedRule"))
            ruleID = randomRulCreate;
        //ruleIDM = CustomSteps.generateRandomRule();
        ApiHelper.sendPutRequestWithHeadersToApp(LSMV_ADMIN_RULE_FREEZE_URL, fromObject(getFileContent(FREEZE_RULE_BODY_PATH).replace("Test", ruleID).replace("summary", publishSummary + ruleID)));
    }

    @When("I get all versions of the rule by rule ID {string}")
    public void iGetRuleDetailsFromRuleID(String ruleID) {
        if (ruleID.equals("CreatedRule"))
            ruleID = randomRulCreate;
        else if (ruleID.equals("invalidRule"))
            ruleID = "invalidRule";
        ApiHelper.sendGetRequestToApp(String.format(LSMV_ADMIN_RULE_URL + "/version/" + ruleID));
    }
    @When("I get version history rule ID {string} and Version {string}")
    public void iGetVersionHistoryOfRuleID(String ruleID,String version) {
        if (ruleID.equals("CreatedRule"))
            ruleID = randomRulCreate;
        else if (ruleID.equals("invalidRule"))
            ruleID = "invalidRule";
        ApiHelper.sendGetRequestToApp(String.format(LSMV_ADMIN_RULE_URL + "/rulehistorydetails/" + ruleID+"/"+version));
    }

    @When("I Export version history rule ID {string} and Version {string}")
    public void iExportVersionHistoryOfRuleID(String ruleID,String version) {
        if (ruleID.equals("CreatedRule"))
            ruleID = randomRulCreate;
        else if (ruleID.equals("invalidRule"))
            ruleID = "invalidRule";
       ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_RULE_URL+"/export/"+ ruleID+"/"+version, fromObject(getFileContent(EMPTY_BODY)));
    }

    @When("I validate response array with all versions of rule with expected")
    public void iValidateJSONResponse(List<Map<String, String>> expectedDataTable) throws IOException {
        Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        String res = response.asString();
        JsonArray jsonary = JsonParser.parseString(res).getAsJsonArray();
        for (int i = 0; i < jsonary.size(); i++) {
            JsonObject jobj = jsonary.get(i).getAsJsonObject();
            String actualRuleID = jobj.get("ruleID").getAsString();
            String actualRuleVersion = jobj.get("ruleVersion").getAsString();
            String actualPublishSummary = jobj.get("publishSummary").getAsString();
            String expectedRuleID = expectedDataTable.get(i).get("ruleID");
            if (expectedRuleID.equals("CreatedRule"))
                expectedRuleID = randomRulCreate;
            String expectedRuleVersion = expectedDataTable.get(i).get("ruleVersion");
            String expectedPublishSummary = expectedDataTable.get(i).get("publishSummary");
            expectedPublishSummary = expectedPublishSummary + expectedRuleID;
            assertEquals(String.format("Expected ruleID " + expectedRuleID + "matches with actual rule ID" + actualRuleID), expectedRuleID, actualRuleID);
            assertEquals(String.format("Expected ruleVersion " + expectedRuleVersion + "matches with actual ruleVersion" + actualRuleVersion), expectedRuleVersion, actualRuleVersion);
            assertEquals(String.format("Expected publishSummary " + expectedPublishSummary + "matches with actual publishsummary " + actualPublishSummary), expectedPublishSummary, actualPublishSummary);
        }
    }
}