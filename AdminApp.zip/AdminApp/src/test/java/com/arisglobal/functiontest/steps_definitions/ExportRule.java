package com.arisglobal.functiontest.steps_definitions;

import com.arisglobal.functiontest.helper.ApiHelper;
import com.arisglobal.functiontest.helper.ApiHelperForNeg;
import com.arisglobal.functiontest.pojo.CreateRuleResponse;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import io.restassured.response.Response;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import static com.arisglobal.functiontest.helper.ApiHelper.sendPostRequest;
import static com.arisglobal.functiontest.hooks.Hooks.scenarioContext;
import static com.arisglobal.functiontest.utils.TestDataUtils.*;
import static com.arisglobal.functiontest.utils.TestUtils.getFileContent;
import static net.sf.json.JSONObject.fromObject;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertEquals;

public class ExportRule {

    @When("I Export all the rules and download as {string} file")
    public void iExportRulesAndDownload(String format) throws IOException {
        switch (format){
            case "PDF" :{
                Response res = sendPostRequest(LSMV_ADMIN_EXPORTRULE_URL, fromObject(getFileContent(EXPORT_RULE_AsPDF_BODY_PATH)));
                String path = "/target/downloads/response.pdf";
                Utils.iDownloadTheFile(res,path);
                break;
            }
            case "DAT" :{
                Response res = sendPostRequest(LSMV_ADMIN_EXPORTRULE_URL, fromObject(getFileContent(EXPORT_RULE_AsDAT_BODY_PATH)));
                String path = "/target/downloads/response.dat";
                Utils.iDownloadTheFile(res,path);
                break;
            }
            case "EXCEL" :{
                Response res = sendPostRequest(LSMV_ADMIN_EXPORTRULE_URL, fromObject(getFileContent(EXPORT_RULE_AsEXCEL_BODY_PATH)));
                String path = "/target/downloads/response.xlsx";
                Utils.iDownloadTheFile(res,path);
                break;
            }

        }

    }
}
