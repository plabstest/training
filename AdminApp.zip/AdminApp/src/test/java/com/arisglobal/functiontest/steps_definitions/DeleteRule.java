package com.arisglobal.functiontest.steps_definitions;

import com.arisglobal.functiontest.helper.ApiHelper;
import com.arisglobal.functiontest.helper.ApiHelperForNeg;
import com.arisglobal.functiontest.pojo.CreateRuleResponse;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import io.restassured.response.Response;

import java.util.List;
import java.util.Map;

import static com.arisglobal.functiontest.hooks.Hooks.scenarioContext;
import static com.arisglobal.functiontest.utils.TestDataUtils.*;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertEquals;

public class DeleteRule {
    final String randomPRule = CreateRule.randomRule;
    @When("I delete existing rule, ruleID: {string}")
    public void iDeleteRuleWithValidRule(String ruleID) {
        if(ruleID.equals("CreatedRule"))
            ruleID=randomPRule;
        ApiHelper.sendDeleteRequestToApp(LSMV_ADMIN_RULE_URL+"?ruleId="+ruleID);
    }
    @When("I delete rule for invalid {string}")
    public void iDeleteRuleForInvalid(String invalidField) {
        ApiHelperForNeg.sendDeleteRequestToApp(LSMV_ADMIN_RULE_URL+"?ruleId=",invalidField);
    }
    @And("get rule response contains rule with below ruleID and Status")
    public void getRuleNResponseContainsRuleWithStatusAndID(List<Map<String, String>> expectedDataTable) {
        Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        CreateRuleResponse getRulesResponse = response.as(CreateRuleResponse.class);
       // String expectedRuleID = expectedDataTable.get(0).get("ruleID");
        String expectedRuleStatus = expectedDataTable.get(0).get("ruleStatus");

       String ruleStatus = getRulesResponse.getRuleStatus();
        if(ruleStatus==null)
            ruleStatus = nullValue().toString();

       // assertEquals(expectedRuleID,getRulesResponse.getRuleID());
        assertEquals(expectedRuleStatus,ruleStatus);
     }
   }
