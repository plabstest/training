package com.arisglobal.functiontest.di;

public class StepDef {
    private static MainComponent instance = null;

    public static MainComponent getInstance() {
        if (instance == null) {
            instance = DaggerMainComponent.builder().build();
        }

        return instance;
    }
}
