package com.arisglobal.functiontest.di;

import com.arisglobal.functiontest.steps_definitions.CustomSteps;
import dagger.Component;

import javax.inject.Singleton;

@Singleton
@Component
public interface MainComponent {
   /* void inject(RulesSteps rulesSteps);

    void inject(CodeEditorSteps codeEditorSteps);

    void inject(EditorTabsSteps editorTabsSteps);

    void inject(LoginSteps loginSteps);

    void inject(MainMenuTabsSteps mainMenuTabsSteps);*/

    void inject(CustomSteps customSteps);

   /* void inject(DataLoaderSteps dataLoaderSteps);

    void inject(LoadRequestPage loadRequestPage);*/
}
