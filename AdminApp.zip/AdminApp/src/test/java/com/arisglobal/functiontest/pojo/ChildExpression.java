package com.arisglobal.functiontest.pojo;

import lombok.Value;

import java.util.List;

@Value
public class ChildExpression {
    String recordId;

    String parentExpId;

    String refRuleConditionId;

    String refRuleId;

    String refRuleName;
    String operator;

    List<ChildCondition> childConditions;
    List<String> childExpressions;
}
