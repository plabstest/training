package com.arisglobal.functiontest.steps_definitions;

import com.arisglobal.functiontest.helper.ApiHelper;
import com.arisglobal.functiontest.helper.ApiHelperForNeg;
import com.arisglobal.functiontest.pojo.CreateRuleResponse;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import net.sf.json.JSONObject;

import java.util.logging.Logger;

import static com.arisglobal.functiontest.hooks.Hooks.scenarioContext;
import static com.arisglobal.functiontest.utils.TestDataUtils.*;
import static com.arisglobal.functiontest.utils.TestUtils.getFileContent;
import static net.sf.json.JSONObject.fromObject;
import static org.junit.Assert.assertEquals;

public class CreateRule {
     static String randomRule;
    @When("I create rule with ruleID {string}")
    public void iCreateRuleWithRuleID(String ruleID) {
         if(ruleID.equals(""))
            ruleID = "";
        else if(!ruleID.equals("CreatedRule"))
            ruleID = CustomSteps.generateRandomRule();
        randomRule = ruleID;
        ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_RULE_URL, fromObject(getFileContent(CREATE_RULE_BODY_PATH).replace("RuleTest6908", ruleID)));
    }
    @When("I create rule with ruleID {string} and Module as {string}")
    public void iCreateRuleWithRuleID(String ruleIDM , String module_name) {
        if (ruleIDM.equals("null"))
            ruleIDM="";
        else if(!ruleIDM.equals(""))
             ruleIDM = CustomSteps.generateRandomRule();
        randomRule = ruleIDM;
        ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_RULE_URL, fromObject(getFileContent(CREATE_RULE_BODY_PATH).replace("RuleTest6908", ruleIDM).replace("Distribution", module_name)));
    }
    @When("I create rule with ruleID {string},ruleName {string} and Module as {string}")
    public void iCreateRuleWithRuleID(String ruleIDM ,String ruleName, String module_name) {
        if (ruleIDM.equals("null"))
            ruleIDM="";
        else if(!ruleIDM.equals(""))
            ruleIDM = CustomSteps.generateRandomRule();
        randomRule = ruleIDM;
        ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_RULE_URL, fromObject(getFileContent(CREATE_RULE_BODY_PATH).replace("RuleTest6908", ruleIDM).replace("Distribution", module_name).replace("RuleTest-name",ruleName)));
    }

    @When("I create Rule with {string}, {string}, {string}, {string}, {string}")
    public void iCreateRuleWith(String RuleID, String RuleName, String RuleDesc, String RuleType, String ModuleName) {
        if (RuleID.equals("null"))
            RuleID="";
        else if(!RuleID.equals(""))
            RuleID = CustomSteps.generateRandomRule();
        randomRule = RuleID;
        ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_RULE_URL, fromObject(getFileContent(CREATE_RULE_RBODY_PATH).replace("RuleID", RuleID).replace("RuleName", RuleName).replace("RuleDescription", RuleDesc).replace("RuleType", RuleType).replace("ModuleName", ModuleName)));
    }

    @When("I create rule already exist in tenant")
    public void iCreateRuleAlreadyExistInTenant() {
        ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_RULE_URL, fromObject(getFileContent(CREATE_RULE_BODY_PATH).replace("RuleTest6908", randomRule)));
    }

    @And("check the response matches with the create rule data for ruleID {string}")
    public void verifyTheResponseMatchesWithTheCreateRuleDataForRuleID(String ruleIDM) {
        Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        CreateRuleResponse getRulesResponse = response.as(CreateRuleResponse.class);
        JSONObject js = fromObject(getFileContent(CREATE_RULE_BODY_PATH));
        String expectedRuleName = js.get("ruleName").toString();
        String expectedRuleType = js.get("ruleType").toString();
        String expectedRuleDesc = js.get("ruleDescription").toString();
        String expectedSystemRuleYN = js.get("systemRuleYN").toString();
        String expectedModuleName = js.get("moduleName").toString();

        assertEquals(randomRule,getRulesResponse.getRuleID());
        assertEquals(expectedRuleName,getRulesResponse.getRuleName());
        assertEquals(expectedRuleDesc,getRulesResponse.getDescription());
        assertEquals(expectedRuleType,getRulesResponse.getRuleType());
        assertEquals(expectedSystemRuleYN,getRulesResponse.getSystemRuleYN());
        assertEquals(expectedModuleName,getRulesResponse.getModuleName());
    }

    @When("I create rule for invalid {string}")
    public void iCreateRuleForInvalid(String invalidField) {
        ApiHelperForNeg.sendPostRequestToAPIForInvalidType(LSMV_ADMIN_RULE_URL, fromObject(getFileContent(CREATE_RULE_BODY_PATH)), invalidField);
    }

    @When("I get the expression text from RuleExpression for invalid {string}")
    public void iGetTheExpressionTextFromRuleExpressionForInvalid(String invalidField) {
        ApiHelperForNeg.sendPostRequestToAPIForInvalidType(LSMV_ADMIN_EXPRESSION_TEXT, fromObject(getFileContent(SIMPLE_EXP_RULE_CONDITIONS_PATH)), invalidField);
    }

    @When("I get the expression text from {string} RuleExpression")
    public void iGetTheExpressionTextFromRuleExpression(String expressionText) {
        if (expressionText.equals("Simple")) {
            JSONObject jsObj = fromObject(getFileContent(SIMPLE_EXP_RULE_CONDITIONS_PATH));
            JSONObject actualJsonObj = jsObj.getJSONObject("ruleExpressions").getJSONArray("childConditions").getJSONObject(1);
            actualJsonObj.put("refRuleConditionId","1677046117210");
            ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_EXPRESSION_TEXT, jsObj);
        }  else if (expressionText.equals("Nested"))
            ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_EXPRESSION_TEXT, fromObject(getFileContent(NESTED_EXPRESSION_RULECONDITIONS_PATH)));
        else {
            ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_EXPRESSION_TEXT,fromObject(getFileContent(SIMPLE_EXP_RULE_CONDITIONS_PATH)));
        }
    }
}
