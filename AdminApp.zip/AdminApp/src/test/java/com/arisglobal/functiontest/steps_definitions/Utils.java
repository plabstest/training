package com.arisglobal.functiontest.steps_definitions;

import com.arisglobal.functiontest.helper.ApiHelper;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.junit.Assert;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static com.arisglobal.functiontest.hooks.Hooks.scenario;
import static com.arisglobal.functiontest.utils.TestDataUtils.*;
import static com.arisglobal.functiontest.utils.TestUtils.getFileContent;
import static net.sf.json.JSONObject.fromObject;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.ss.usermodel.Row;


public class Utils {

    public static void validateJSON(Response response, String ruleID,String field, String status) throws IOException {
        JsonPath  jsonPathEvaluator = response.jsonPath();
        String actual_status = jsonPathEvaluator.get(field);
        String expected_status = status;
        Assert.assertEquals(expected_status, actual_status);
        if(expected_status.equalsIgnoreCase(actual_status)){
            scenario.log("The field name " + field + " for " + ruleID +" is proper");
        }
        else
            scenario.log("The field name " + field + " for " + ruleID +" is not proper");


    }
    public static void iDownloadTheFile(Response res,String path) throws IOException {
        if (res.statusCode() == 200) {
            scenario.log("Succesfully exported");
            byte[] dowloadedfilebyte = res.asByteArray();

            String ss = res.asPrettyString();

            try {
                FileOutputStream fos = new FileOutputStream(System.getProperty("user.dir")+path);
                fos.write(dowloadedfilebyte);
                fos.close();
                scenario.log("File downloaded successfully in the path--> "+ System.getProperty("user.dir")+path);
            }
            catch (Exception log){
                log.printStackTrace();
            }
        }

    }
    @And("Verify {string} file has contents")
    public static void validateContentInFile(String file_format ,DataTable Rule_Names) throws IOException {
        List<Map<String, String>> data = Rule_Names.asMaps(String.class, String.class);
        switch (file_format) {
            case "PDF": {
                String url = System.getProperty("user.dir") + "/target/downloads/response.pdf";
                File file = new File(url);
                PDDocument document = PDDocument.load(file);
                //Instantiate PDFTextStripper class
                PDFTextStripper pdfStripper = new PDFTextStripper();
                //Retrieving text from PDF document
                String pdfContent = pdfStripper.getText(document);
                for (int i = 0; i < data.size(); i++) {
                    String ruleNames = data.get(i).get("Rule_Names");
                    Assert.assertTrue(pdfContent.contains(ruleNames));
                    scenario.log("PASS : Pdf contains the value " + ruleNames);
                }
                break;
            }

            case "DAT": {
                Response res = ApiHelper.sendPostRequest(LSMV_ADMIN_EXPORTRULE_URL, fromObject(getFileContent(EXPORT_RULE_AsDAT_BODY_PATH)));
                if (res.statusCode() == 200) {
                    JsonPath jsonPathEvaluator = res.jsonPath();
                    String actual_ruleName = jsonPathEvaluator.getString("ruleName");
                    String[] all_rules = actual_ruleName.trim().split(", ");
                    List all_rulesList = Arrays.asList(all_rules);
                    for (int i = 0; i < data.size(); i++) {
                        String expected_ruleNames = data.get(i).get("Rule_Names");
                        if (all_rulesList.contains(expected_ruleNames))
                            scenario.log("PASS: " + "Rule name " + expected_ruleNames + " is present in DAT file");
                        else
                            scenario.log("FAIL: " + "Rule name " + expected_ruleNames + " is not present in DAT file");
                    }
                }
                break;
            }
            case "EXCEL": {
                Response res = ApiHelper.sendPostRequest(LSMV_ADMIN_EXPORTRULE_URL, fromObject(getFileContent(EXPORT_RULE_AsEXCEL_BODY_PATH)));
                if (res.statusCode() == 200) {
                    String url = System.getProperty("user.dir") + "/target/downloads/response.xlsx";
                    FileInputStream fileInput = new FileInputStream(url);
                    XSSFWorkbook rulebook = new XSSFWorkbook(fileInput);
                    int rowCount = rulebook.getSheet("RuleDetails").getLastRowNum() - rulebook.getSheet("RuleDetails").getFirstRowNum();
                    System.out.println("Total rows " + rowCount);
                    XSSFSheet row = rulebook.getSheet("RuleDetails");
                    String val = row.getRow(4).getCell(0).getStringCellValue();
                    Row cell = row.getRow(4).getCell(0).getRow();
                    int columnsCount = cell.getLastCellNum();

                    //check inside excel to validate rules
                    for (int rows = 4; rows < rowCount; rows++) {
                        for (int columns = 0; columns < 1; columns++) {
                            String actualRuleNames = row.getRow(rows).getCell(columns).getStringCellValue();
                            for (int rules = 0; rules < data.size(); rules++) {
                                String expectedRuleNames = data.get(rules).get("Rule_Names");
                                if (expectedRuleNames.equalsIgnoreCase(actualRuleNames))
                                    scenario.log("Rulename - " + expectedRuleNames + " is available");
                            }
                        }
                    }
                    break;
                }
            }

        }

    }
}
