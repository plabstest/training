package com.arisglobal.functiontest.runner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = {"pretty", "html:target/cucumber-report.html", "json:target/jsonReports/cucumber.json","junit:target/cucumber.xml"},
        glue = "com.arisglobal.functiontest",
       //features = "src/test/resources/features/2023.2.0.0"
        features = "src/test/resources/features/backend"
)

public class TestRunner extends AbstractTestNGCucumberTests {
}
