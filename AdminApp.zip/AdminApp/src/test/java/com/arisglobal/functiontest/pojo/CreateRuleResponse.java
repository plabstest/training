package com.arisglobal.functiontest.pojo;

import lombok.Value;

import java.util.List;

@Value
public class CreateRuleResponse {
    String compilationErrorsJSON;
    String appDataCapaNo;
    String tempSequence;
    String libSelectedParamJson;
    String recordId;
    String objectId;
    String formRecordid;
    String otherFormRecordid;
    String classDn;
    String userModified;
    String dateModified;
    String createdBy;
    String dateCreated;
    String reasonCode;
    String reason;
    String sprId;
    String parentRuleId;
    String ruleID;
    String ruleName;
    String isValid;
    String activeYN;
    String exculdableRule;
    String ruleStatus;
    String ruleFields;
    String conditionExpression;
    String scriptedYN;
    String ruleScript;
    String ruleType;
    String description;
    String systemRuleYN;
    String caseFrequency;
    String ooWfStatusForSampling;
    String ruleParamMap;
    String ruleExpressionJson;
    RuleExpression ruleExpression;
    List<RuleCondition> ruleConditions;
    String moduleName;
    String lockedByUser;
    String forTest;
    List<String> ruleOutcomes;
    List<String> adhocRules;
    String modifiedOn;
    String createdOn;
    String actionItems;
    String modifiedBy;
    String ruleConditionsJson;
    String sameContextYN;
    String  triggerOnNewYN;
    String alwaysExecuteYN;
    List<String> libSelectedParams;
    String objectCreatedOnMerge;
    String dataMerged;
    String sourceId;
    String targetId;
    String synchronizedDate;
    String userId;

    String moduleId;

    String appDataName;

    String appDataValue;
    String disableRemove;
    String systemAddress;
    String donotAudit;
    String workFlowActivityId;
    String wfName;
    String appDataAerNo;
    String appDataLrnNo;
    String appData1;
    String capaNo;
    String relVersion;
    String ruleVersion;
    String sequence;
    String isStd;
    String prevCaseFields;
    String ruleOutcomesJson;
    String adhocRulesJson;
    String publishSummary;
}
