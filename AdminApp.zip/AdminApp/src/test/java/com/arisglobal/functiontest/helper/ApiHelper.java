package com.arisglobal.functiontest.helper;

import io.restassured.response.Response;
import net.sf.json.JSONObject;
import org.springframework.http.HttpStatus;

import java.io.File;
import java.util.HashMap;

import static com.arisglobal.functiontest.helper.Context.*;
import static com.arisglobal.functiontest.hooks.Hooks.scenarioContext;
import static io.restassured.RestAssured.given;

public class ApiHelper {
    public static String Tenant = "LSMV_ADMIN_1";
    public static String UserName = "administrator";
    public static String tenant_code = "LSMV_ADMIN_1";

    public static HashMap<String, String> map = new HashMap<>();
    public static void ChangeTenant(String tenant) {
        Tenant = tenant;
    }

    public static void ChangeUserName(String userName) {
        UserName = userName;
    }
    private static void saveResponse(Response response) {
        response.then().log().all();
        scenarioContext.setVariable(RESPONSE, response);
        scenarioContext.setVariable(RESPONSE_BODY, response.asString());
        scenarioContext.setVariable(RESPONSE_STATUS, response.getStatusCode());
    }

    public static void sendGetRequestToApp(String url) {
        Response response = given().header("Authorization", "Bearer " + scenarioContext.getScenarioVariables().get("TOKEN")).header("username", "administrator").header("#tenant_code#", Tenant)
                .log().everything().relaxedHTTPSValidation().get(url).andReturn();
        saveResponse(response);

    }
    public static Response sendGetRequest(String url) {
        Response response = given().header("Authorization", "Bearer " + scenarioContext.getScenarioVariables().get("TOKEN")).header("username", "administrator").header("#tenant_code#", Tenant)
                .log().everything().relaxedHTTPSValidation().get(url).andReturn();
        saveResponse(response);
        return response;

    }

    public static void sendPostRequestWithHeadersToApp(String url, JSONObject requestBody) {
        Response response = given().header("Authorization", "Bearer " + scenarioContext.getScenarioVariables().get("TOKEN")).header("username", "administrator").header("#tenant_code#", Tenant)
                .log().everything().header("Content-Type", "application/json").relaxedHTTPSValidation().body(requestBody).post(url).andReturn();
        saveResponse(response);
    }
    public static Response sendPostRequest(String url, JSONObject requestBody) {
        map.put("Authorization", "Bearer " + scenarioContext.getScenarioVariables().get("TOKEN"));
        map.put("username", "administrator");
        map.put("#tenant_code#", tenant_code);
        map.put("Content-Type", "application/json");
        Response response = given().headers(map).log().everything().
                relaxedHTTPSValidation().body(requestBody).post(url).andReturn();
        saveResponse(response);
        return response;

    }
    public static void sendDeleteRequestToApp(String url) {
        Response response = given().header("Authorization", "Bearer " + scenarioContext.getScenarioVariables().get("TOKEN")).header("username",UserName).header("#tenant_code#", Tenant)
                .log().everything().relaxedHTTPSValidation().delete(url).andReturn();
        saveResponse(response);
    }

    public static void sendPutRequestWithHeadersToApp(String url, JSONObject requestBody) {
        Response response = given().header("Authorization", "Bearer " + scenarioContext.getScenarioVariables().get("TOKEN")).header("username",UserName).header("#tenant_code#", Tenant)
                .log().everything().header("Content-Type", "application/json").relaxedHTTPSValidation().body(requestBody)
                .put(url).andReturn();
        saveResponse(response);
    }
    public static void sendPutRequestToApp(String url) {
        Response response = given().header("Authorization", "Bearer " + scenarioContext.getScenarioVariables().get("TOKEN")).header("username",UserName).header("#tenant_code#", Tenant)
                .log().everything().header("Content-Type", "application/json").relaxedHTTPSValidation()
                .put(url).andReturn();
        saveResponse(response);
    }

    public static void sendPutMultipartRequestToApp(String url, String uploadFileName) {
        Response response = given().header("Content-Type", "multipart/form-data")
                .multiPart("customRuleFile", new File("./src/test/resources/payload/rules/" + uploadFileName + ".json"))
                .log().uri().relaxedHTTPSValidation().put(url).andReturn();
        saveResponse(response);
    }

    public static Integer getReceivedStatusCode() {
        return Integer.parseInt(scenarioContext.getScenarioVariables().get(RESPONSE_STATUS.toString()).toString());
    }

    public static Integer getStatusCode(String expectedStatusCode) {
        try {
            return HttpStatus.valueOf(expectedStatusCode).value();
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}