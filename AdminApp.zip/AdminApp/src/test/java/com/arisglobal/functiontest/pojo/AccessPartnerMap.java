package com.arisglobal.functiontest.pojo;

import lombok.Value;

@Value
public class AccessPartnerMap {
            String recordId;
            String country;
            String senderId;
            String senderOrg;
            String name;
            String isE2BPartner;
            String partnerId;
            String type;
            String senderOrgType;
}
