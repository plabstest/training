package com.arisglobal.functiontest.steps_definitions;

import com.arisglobal.functiontest.helper.ApiHelper;
import com.arisglobal.functiontest.helper.ApiHelperForNeg;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.sf.json.test.JSONAssert;

import static com.arisglobal.functiontest.hooks.Hooks.scenarioContext;
import static com.arisglobal.functiontest.utils.TestDataUtils.*;
import static com.arisglobal.functiontest.utils.TestUtils.getFileContent;
import static net.sf.json.JSONObject.fromObject;

public class GetAllRulesFromRuleBuilder {
    @When("I get all Rules and its Details from RuleBuilder")
    public void iGetAllRulesAndItsDetailsFromRuleBuilder() {
        ApiHelper.sendGetRequestToApp(LSMV_ADMIN_RULES_RULEBUILDER);
    }
    @When("I get all Rules Details from RuleBuilder")
    public void iGetAllRulesDetailsFromRuleBuilder() {
        ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_RULEDETAILS,fromObject(getFileContent(GET_ALLRULES_BODY_PATH)));
    }

    @And("get response contains all Rules and its Details from RuleBuilder")
    public void getResponseContainsAllRulesAndItsDetailsFromRuleBuilder()
    {
        JSONAssert.assertJsonEquals(getFileContent(RULES_RULEBUILDER_RESPONSE_PATH),
                scenarioContext.getScenarioVariables().get("RESPONSE_BODY").toString());
    }

    @When("I get all Rules and its Details from RuleBuilder for invalid {string}")
    public void iGetAllRulesAndItsDetailsFromRuleBuilderForInvalid(String invalidField) {
        ApiHelperForNeg.sendGetRequestToAPIForInvalidType(LSMV_ADMIN_RULES_RULEBUILDER, invalidField);
    }

    @When("I get all Supported Forms & Module Type Dropdown for {string}")
    public void iGetAllSupportedFormsModuleTypeDropdownFor(String ruleName) {
        ApiHelper.sendGetRequestToApp(LSMV_ADMIN_RULE_URL+"/modulesAndForms/"+ruleName);
    }

    @Then("verify the response contains all Supported Forms & Module  for {string}")
    public void verifyTheResponseContainsAllSupportedFormsModuleFor(String ruleName) {
//        if(ruleName.equals("Condition")||ruleName.equals("Alert")||ruleName.equals("Follow-up")) {
//            JSONObject jsObj = fromObject(getFileContent(MODULES_FORMS));
//            jsObj.remove("CAL");
//            JSONAssert.assertJsonEquals(jsObj.toString(),
//                    scenarioContext.getScenarioVariables().get("RESPONSE_BODY").toString());
//        }
//        else
        JSONAssert.assertJsonEquals(getFileContent(MODULES_FORMS),
                scenarioContext.getScenarioVariables().get("RESPONSE_BODY").toString());

    }

    @When("I get all Supported Forms & Module Type Dropdown for invalid {string}")
    public void iGetAllSupportedFormsModuleTypeDropdownForInvalid(String invalidField) {
        ApiHelperForNeg.sendGetRequestToAPIForInvalidType(LSMV_ADMIN_RULE_URL+"modulesAndForms/Alert", invalidField);
    }
}
