package com.arisglobal.functiontest.helper;

import com.arisglobal.functiontest.hooks.Hooks;
import groovy.util.logging.Slf4j;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Data
@RequiredArgsConstructor
public class ScenarioContext {
    private final Map<String, Object> scenarioVariables = new HashMap<>();
    private static final Logger LOG = LoggerFactory.getLogger(Hooks.class);

    public ScenarioContext setVariable(Context variableName, Object variableValue) {
        this.scenarioVariables.put(String.valueOf(variableName), variableValue);
        return this;
    }

    public void clear() {
        this.scenarioVariables.clear();
    }
}
