package com.arisglobal.functiontest.pojo;

import lombok.Data;
import lombok.Value;

@Value
public class RuleCondition {
    String recordId;
    String index;
    String anyOneLhs;
    String lhsFunc;
    String lhsField;
    String lhsFieldString;
    String lhsFilterConddExp;
    String lhsFilterConddLogic;
    String lhsFieldcodelistId;
    String lhsDataType;
    String lhsFilters;
    String operator;
    String parameterizedRhs;
    String rhsFunc;
    String rhsField;
    String rhsConst;
    String rhsFilterConddExp;
    String rhsFilterConddLogic;
    String rhsFilters;
    String ruleCondDisplayStr;
    String referenceRuleID;
    String referenceRuleName;
    String nfMarked;
    String prevCaseYN;
    String rhsFlPrevCaseYN;
}
