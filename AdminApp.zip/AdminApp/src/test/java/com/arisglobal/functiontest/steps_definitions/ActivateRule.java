package com.arisglobal.functiontest.steps_definitions;

import com.arisglobal.functiontest.helper.ApiHelper;
import com.arisglobal.functiontest.helper.ApiHelperForNeg;
import com.arisglobal.functiontest.pojo.CreateRuleResponse;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import io.restassured.response.Response;

import java.util.List;
import java.util.Map;

import static com.arisglobal.functiontest.hooks.Hooks.scenarioContext;
import static com.arisglobal.functiontest.utils.TestDataUtils.LSMV_ADMIN_RULE_URL;
import static com.arisglobal.functiontest.utils.TestDataUtils.LSMV_ADMIN_RULE_ActivateOrDeactivate;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertEquals;

public class ActivateRule {
    final String randomPRule = CreateRule.randomRule;
    String Rand= CustomSteps.generateRandomRule();
    @And("get rule response contains rule with below ruleID and active")
    public void getRuleNResponseContainsRuleWithActiveAndID(List<Map<String, String>> expectedDataTable) {
        Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        CreateRuleResponse getRulesResponse = response.as(CreateRuleResponse.class);
       // String expectedRuleID = expectedDataTable.get(0).get("ruleID");
        String expectedRuleIsActive = expectedDataTable.get(0).get("active");

        String ruleIsactive = getRulesResponse.getActiveYN();
        if(ruleIsactive==null)
            ruleIsactive = nullValue().toString();

        System.out.println(expectedRuleIsActive);
       // assertEquals(expectedRuleID,getRulesResponse.getRuleID());
        assertEquals(expectedRuleIsActive,ruleIsactive);
    }
    @When("I Activate rule, ruleID: {string}")
    public void iActivateExistingRuleRuleID(String ruleID) {
        ApiHelper.sendPutRequestToApp(String.format(LSMV_ADMIN_RULE_ActivateOrDeactivate,randomPRule,"true"));
    }

    @When("I Activate rule for invalid {string}")
    public void iActivateRuleForInvalid(String invalidField) {
        ApiHelperForNeg.sendPutRequestToApp(String.format(LSMV_ADMIN_RULE_ActivateOrDeactivate,randomPRule,"true"),invalidField);
    }
    @When("I Deactivate rule for invalid {string}")
    public void iDeactivateRuleForInvalid(String invalidField) {
        ApiHelperForNeg.sendPutRequestToApp(String.format(LSMV_ADMIN_RULE_ActivateOrDeactivate,randomPRule,"false"),invalidField);
    }
    @When("I Deactivate rule, ruleID: {string}")
    public void iDeactivateRuleRuleID(String ruleID) {
        ApiHelper.sendPutRequestToApp(String.format(LSMV_ADMIN_RULE_ActivateOrDeactivate,randomPRule,"false"));
    }
}
