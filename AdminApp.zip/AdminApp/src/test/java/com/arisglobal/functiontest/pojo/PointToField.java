package com.arisglobal.functiontest.pojo;

import lombok.Value;

@Value
public class PointToField {
    String fieldName;
    String fieldId;

}
