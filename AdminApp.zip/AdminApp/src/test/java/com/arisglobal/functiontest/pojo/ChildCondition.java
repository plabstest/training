package com.arisglobal.functiontest.pojo;

import lombok.Value;

import java.util.List;

@Value
public class ChildCondition {
    String recordId;
    String parentExpId;
    String refRuleConditionId;
    String refRuleId;
    String refRuleName;
    String operator;
    List<String> childConditions;
    List<String> childExpressions;
}
