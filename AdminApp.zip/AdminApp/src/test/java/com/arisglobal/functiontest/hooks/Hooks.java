package com.arisglobal.functiontest.hooks;

import com.arisglobal.functiontest.helper.GenerateToken;
import com.arisglobal.functiontest.helper.ScenarioContext;
import groovy.util.logging.Slf4j;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import static com.arisglobal.functiontest.helper.Context.SCENARIO;

@Slf4j
public class Hooks {
    private static final Logger LOG = LoggerFactory.getLogger(Hooks.class);
    public static ScenarioContext scenarioContext;
    public static Scenario scenario;

    @Before
    public void before(Scenario scenario) {
        ScenarioContext scenarioContext = new ScenarioContext() {};
        LOG.info("Before Scenarios");
        Hooks.scenario = scenario;
        Hooks.scenarioContext = scenarioContext;

        scenarioContext.setVariable(SCENARIO, scenario);
        GenerateToken.getToken();
    }

    @After
    public void after() {
        LOG.info("After");
        if (scenario.isFailed()) {
            System.out.println("Test Failed---> " + scenario.getName());
        }
        scenarioContext.clear();
    }
}
