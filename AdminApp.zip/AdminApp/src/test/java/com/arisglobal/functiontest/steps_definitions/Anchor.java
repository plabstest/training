package com.arisglobal.functiontest.steps_definitions;

import com.arisglobal.functiontest.helper.ApiHelper;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import net.sf.json.JSONObject;


import static com.arisglobal.functiontest.hooks.Hooks.scenarioContext;
import static com.arisglobal.functiontest.utils.TestDataUtils.*;
import static com.arisglobal.functiontest.utils.TestUtils.getFileContent;
import static net.sf.json.JSONObject.fromObject;
import static org.junit.Assert.assertEquals;

public class Anchor {
    @When("^I update the Anchor for (.+) to (.+)$")
    public void iUpdateTheAnchorForAnd(String fieldName, String fieldValue) {
        JSONObject jsObj = fromObject(getFileContent(GET_ANCHOR_PATH));
        if (jsObj.getJSONObject("anchor").containsKey(fieldName)) {
            jsObj.getJSONObject("anchor").replace(fieldName, fieldValue);
        } else jsObj.getJSONObject("anchor").put(fieldName, fieldValue);
        ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_DISCONTACT_RULE, jsObj);
    }

    @When("^I update the Anchor distribution rule set values for (.+) to (.+)$")
    public void iUpdateTheAnchorForDistributionRuleSet(String fieldName, String fieldValue) {
        JSONObject jsObj = fromObject(getFileContent(GET_ANCHOR_PATH));
        JSONObject actualJsonObj = jsObj.getJSONObject("anchor").getJSONArray("distributionRulesSet").getJSONObject(0);
        if (actualJsonObj.containsKey(fieldName)) {
            actualJsonObj.replace(fieldName, fieldValue);
        } else actualJsonObj.put(fieldName, fieldValue);
        ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_DISCONTACT_RULE, jsObj);
    }

    @Then("verify the response for (.+) to (.+)$")
    public void verifyTheResponseForFieldNameAndFieldValue(String fieldName, String fieldValue)  {
        Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        String res = response.asString();
        JsonObject json = JsonParser.parseString(res).getAsJsonObject();
        String actualFieldValue = json.get(fieldName).getAsString();
        if (actualFieldValue != null) {
            assertEquals(fieldValue, actualFieldValue);
        }
    }

    @Then("^verify the response distributionSet field values (.+) to (.+)$")
    public void verifyTheResponseDistributionSetFieldValues(String fieldName, String fieldValue) {

        Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        String res = response.asString();
        JsonObject jsonObj = JsonParser.parseString(res).getAsJsonObject();
        JsonObject disRulesSetJsonObj = jsonObj.getAsJsonArray("distributionRulesSet").get(0).getAsJsonObject();
        String actualFieldValue = disRulesSetJsonObj.get(fieldName).toString();
        if (actualFieldValue != null) {
            assertEquals(fieldValue, actualFieldValue);
        }
    }
}


