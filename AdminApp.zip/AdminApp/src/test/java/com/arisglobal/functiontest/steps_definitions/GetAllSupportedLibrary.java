package com.arisglobal.functiontest.steps_definitions;

import com.arisglobal.functiontest.helper.ApiHelper;
import com.arisglobal.functiontest.helper.ApiHelperForNeg;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import net.sf.json.test.JSONAssert;

import static com.arisglobal.functiontest.hooks.Hooks.scenarioContext;
import static com.arisglobal.functiontest.utils.TestDataUtils.*;
import static com.arisglobal.functiontest.utils.TestUtils.getFileContent;
import static net.sf.json.JSONObject.fromObject;

public class GetAllSupportedLibrary {
    @When("I get all supported Library from Library filter option")
    public void iGetAllSupportedLibraryFromLibraryFilterOption() {
        ApiHelper.sendGetRequestToApp(LSMV_ADMIN_LIBRARY_RULES);
    }

    @And("get rule response contains all supported Library")
    public void getRuleResponseContainsAllSupportedLibrary() {
        JSONAssert.assertJsonEquals(fromObject(getFileContent(RULES_SUPPORTED_LIBRARY_RESPONSE_PATH)).toString(),
                scenarioContext.getScenarioVariables().get("RESPONSE_BODY").toString());

    }

    @When("I get all supported Library from Library filter option for invalid {string}")
    public void iGetAllSupportedLibraryFromLibraryFilterOptionForInvalid(String invalidField) {
        ApiHelperForNeg.sendGetRequestToAPIForInvalidType(LSMV_ADMIN_LIBRARY_RULES, invalidField);
    }
}
