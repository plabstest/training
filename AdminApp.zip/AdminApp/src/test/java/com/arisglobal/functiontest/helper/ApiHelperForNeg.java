package com.arisglobal.functiontest.helper;

import io.restassured.response.Response;
import net.sf.json.JSONObject;
import static com.arisglobal.functiontest.helper.Context.*;
import static com.arisglobal.functiontest.hooks.Hooks.scenarioContext;
import static io.restassured.RestAssured.given;

public class ApiHelperForNeg {
    public static String userName = "administrator";
    public static String isInvalid = "";

    private static void saveResponse(Response response) {
        response.then().log().all();
        scenarioContext.setVariable(RESPONSE, response);
        scenarioContext.setVariable(RESPONSE_BODY, response.asString());
        scenarioContext.setVariable(RESPONSE_STATUS, response.getStatusCode());
    }

    public static void validateInValidHeaderORToken(String invalidField) {
        if (invalidField.equalsIgnoreCase("token"))
            isInvalid = "invalid";
        else if (invalidField.equalsIgnoreCase("username")) {
            isInvalid = "";
            userName = "gitsUser";
        }
    }

    public static void sendGetRequestToAPIForInvalidType(String url, String invalidField) {
        validateInValidHeaderORToken(invalidField);
        Response response = given().header("Authorization", "Bearer " + scenarioContext.getScenarioVariables().get("TOKEN") + isInvalid).header("username", userName).header("#tenant_code#", "AG_AGX_MAIN_DS")
                .log().everything().relaxedHTTPSValidation().get(url).andReturn();
        saveResponse(response);
    }

    public static void sendPostRequestToAPIForInvalidType(String url, JSONObject requestBody, String invalidField) {
        validateInValidHeaderORToken(invalidField);
        Response response = given().header("Authorization", "Bearer " + scenarioContext.getScenarioVariables().get("TOKEN" + isInvalid)).header("username", userName).header("#tenant_code#", "AG_AGX_MAIN_DS")
                .log().everything().header("Content-Type", "application/json").relaxedHTTPSValidation().body(requestBody).post(url).andReturn();
        saveResponse(response);
    }

        public static void sendDeleteRequestToApp(String url,String invalidField) {
            validateInValidHeaderORToken(invalidField);
            Response response = given().header("Authorization", "Bearer " + scenarioContext.getScenarioVariables().get("TOKEN"+ isInvalid)).header("username", userName).header("#tenant_code#", "AG_AGX_MAIN_DS")
                    .log().everything().relaxedHTTPSValidation().delete(url).andReturn();
            saveResponse(response);
        }

    public static void sendPutRequestToApp(String url,String invalidField) {
        validateInValidHeaderORToken(invalidField);
        Response response = given().header("Authorization", "Bearer " + scenarioContext.getScenarioVariables().get("TOKEN"+ isInvalid)).header("username", userName).header("#tenant_code#", "AG_AGX_MAIN_DS")
                .log().everything().header("Content-Type", "application/json").relaxedHTTPSValidation()
               .put(url).andReturn();
        saveResponse(response);
    }
}