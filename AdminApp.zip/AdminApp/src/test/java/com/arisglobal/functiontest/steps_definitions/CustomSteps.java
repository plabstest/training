package com.arisglobal.functiontest.steps_definitions;

import com.arisglobal.functiontest.config.ConfigFileReader;
import com.arisglobal.functiontest.di.StepDef;
import com.arisglobal.functiontest.helper.ApiHelper;
import com.codeborne.selenide.WebDriverRunner;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import org.apache.commons.lang.RandomStringUtils;

import javax.inject.Inject;

import static com.arisglobal.functiontest.helper.ApiHelper.getStatusCode;
import static com.arisglobal.functiontest.hooks.Hooks.scenarioContext;
import static com.codeborne.selenide.Selenide.open;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class CustomSteps {
    @Inject
    ConfigFileReader configFileReader;

    public CustomSteps() {
        StepDef.getInstance().inject(this);
    }

    @When("a response with 200 is returned")
    public void a200isReturned() {
        assertEquals(getStatusCode("OK"), ApiHelper.getReceivedStatusCode());
    }

    @When("a response with 201 is returned")
    public void a201isReturned() {
        assertEquals(getStatusCode("CREATED"), ApiHelper.getReceivedStatusCode());
    }

    @Then("a response with 404 is returned")
    public void aResponseWith404IsReturned() {
        assertEquals(getStatusCode("NOT_FOUND"), ApiHelper.getReceivedStatusCode());
    }

    @Then("a response with 409 is returned")
    public void aResponseWith409IsReturned() {
        assertEquals(getStatusCode("CONFLICT"), ApiHelper.getReceivedStatusCode());
    }

    @Then("a response with 403 is returned")
    public void aResponseWith403IsReturned() {
        assertEquals(getStatusCode("FORBIDDEN"), ApiHelper.getReceivedStatusCode());
    }

    @Then("a response with 304 is returned")
    public void aResponseWith304IsReturned() {
        assertEquals("304", ApiHelper.getReceivedStatusCode().toString());
    }

    @Then("a response with 500 is returned")
    public void aResponseWith500IsReturned() {
        assertEquals(getStatusCode("INTERNAL_SERVER_ERROR"), ApiHelper.getReceivedStatusCode());
    }

    @Given("I go to main page")
    public void iGoToMainPage() {
        open(configFileReader.getProperty("environment"));
    }

    @And("I open {string} page")
    public void iOpenPage(String subUrl) {
        open(configFileReader.getProperty("environment") + subUrl);
    }

    @Then("I should be on {string} - {string} page")
    public void iShouldBeOnPage(String menuItemName, String submenuItemName) {
        if (menuItemName.contains(" ")) {
            menuItemName = menuItemName.substring(0, menuItemName.indexOf(" "));
        }
        if (submenuItemName.contains(" ")) {
            submenuItemName = submenuItemName.substring(0, submenuItemName.indexOf(" "));
        }
        assertTrue(WebDriverRunner.url().contains(menuItemName.toLowerCase()));
        assertTrue(WebDriverRunner.url().contains("/" + submenuItemName.toLowerCase()));
    }

    @Then("a response with 400 is returned")
    public void aResponseWith400IsReturned() {
        assertEquals(getStatusCode("BAD_REQUEST"), ApiHelper.getReceivedStatusCode());
    }

    @Given("I am in Tenant {string}")
    public void iAmInTenant(String tenant) {
        ApiHelper.ChangeTenant(tenant);
    }

    @Given("I am in User {string}")
    public void iaminUser(String userName) {
        ApiHelper.ChangeUserName(userName);
    }

    @Then("a response with {string} is returned")
    public void aResponseWithIsReturned(String statusCode) {
        if (statusCode.equals("500"))
            assertEquals(getStatusCode("INTERNAL_SERVER_ERROR"), ApiHelper.getReceivedStatusCode());
        else if(statusCode.equals("403")) assertEquals(getStatusCode("FORBIDDEN"), ApiHelper.getReceivedStatusCode());
    }

    @And("Check the response matches {string}")
    public void checkTheResponseMatches(String expectedText) {
        Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        String actualResponse = response.asString();
        assertEquals(expectedText.trim(),actualResponse.trim());
    }

    public static String generateRandomRule() {
        String RandAlpha = RandomStringUtils.randomAlphabetic(4);
        String RandAlphaNum = RandomStringUtils.randomAlphanumeric(4);
        return "Rule"+RandAlpha+RandAlphaNum.toString();
    }
}
