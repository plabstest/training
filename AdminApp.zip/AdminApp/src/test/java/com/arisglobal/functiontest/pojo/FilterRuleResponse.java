package com.arisglobal.functiontest.pojo;

import lombok.Data;

import java.util.List;

@Data
public class FilterRuleResponse {
    String noOfRecords;
    List<PageData> pageData;
}
