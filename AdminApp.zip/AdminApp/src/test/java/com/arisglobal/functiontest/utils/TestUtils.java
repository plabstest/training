package com.arisglobal.functiontest.utils;

import com.codeborne.selenide.Configuration;
import io.cucumber.java.Before;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.util.Objects;

//import static com.codeborne.selenide.Selenide.executeJavaScript;
import static java.lang.System.getenv;
import static java.nio.charset.StandardCharsets.UTF_8;

@Slf4j
public class TestUtils {

    private TestUtils() {
    }

    public static String getEnvOrDefault(final String envKey, final String defaultValue) {
        final String value = getenv(envKey);
        if (Objects.nonNull(value)) {
            return value;
        } else {
            log.warn("Value of \"{}\" not found in env file. The default value will be used: {}", envKey, defaultValue);
            return defaultValue;
        }
    }

    public static String getFileContent(final String filename) {
        try {
            return IOUtils.toString(new ClassPathResource(filename).getInputStream(), UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    @Before
    public static void beforeEach() {
        Configuration.browserSize = "1920x1080";
        Configuration.timeout = 10000;
    }
}