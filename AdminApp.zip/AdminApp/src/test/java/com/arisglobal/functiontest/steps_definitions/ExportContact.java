package com.arisglobal.functiontest.steps_definitions;

import io.cucumber.java.en.When;
import io.restassured.response.Response;

import java.io.IOException;

import static com.arisglobal.functiontest.helper.ApiHelper.sendPostRequest;
import static com.arisglobal.functiontest.utils.TestDataUtils.*;
import static com.arisglobal.functiontest.utils.TestUtils.getFileContent;
import static net.sf.json.JSONObject.fromObject;

public class ExportContact {

    @When("I Export all the contacts and download as {string} file")
    public void iExportContactAndDownload(String format) throws IOException {
        switch (format){
            case "DAT" :{
                Response res = sendPostRequest(LSMV_ADMIN_EXPORTCONTACT_AsDat_URL, fromObject(getFileContent(EXPORT_CONTACT_BODY_PATH)));
                String path = "/target/downloads/response.dat";
                Utils.iDownloadTheFile(res,path);
                break;
            }
            case "EXCEL" :{
                Response res = sendPostRequest(LSMV_ADMIN_EXPORTCONTACT_AsExcel_URL, fromObject(getFileContent(EXPORT_CONTACT_BODY_PATH)));
                String path = "/target/downloads/response.xlsx";
                Utils.iDownloadTheFile(res,path);
                break;
            }

        }

    }
}
