package com.arisglobal.functiontest.pojo;

import lombok.Value;

@Value
public class AuthenticationResponse {
    String access_token;
    String expires_in;
    String token_type;
}
