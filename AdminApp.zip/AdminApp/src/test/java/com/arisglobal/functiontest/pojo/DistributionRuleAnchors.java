package com.arisglobal.functiontest.pojo;

import lombok.Data;
import lombok.Value;

import java.util.List;

@Data @Value
public class DistributionRuleAnchors {
    String recordId;
    String objectId;
    String classDn;
    String userModified;
    String dateModified;
    String createdBy;
    String dateCreated;
    String reasonCode;
    String reason;
    String sprId;
    String displayName;
    String isActive;
    String isArchived;
    String reCalculateSubmissionDate;
    String description;
    String reportType;
    String startDate;
    String endDate;
    String pivotRuleValues;
    String timeLineDays;
    String ruleInclusionLogic;
    List<DistributionRulesSet> distributionRulesSet;
    PivotRule pivotRule;
    String paramMap;
    String affliateSubmissionTimeLineDays;
    String importComments;
    String version;
    String sequence;
    String excludePivotRule;
    String inclusionLogicJSON;
    String findTimeLineDueDateBasedOn;

    String trustedPartner;
    String mhlwReportType;
    String mhlwDeviceReportType;
    String mhlwRegenerativeReportType;
    String completeFlag;
    String locallyExpedited;
    String immediateReportFlag;

}
