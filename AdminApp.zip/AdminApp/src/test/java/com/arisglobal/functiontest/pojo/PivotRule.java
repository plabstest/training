package com.arisglobal.functiontest.pojo;

import lombok.Value;

@Value
public class PivotRule {
            String pivotRuleValues;
            String timeLineDays;
            String ruleInclusionLogic;
            String distributionRulesSet;
            String paramMap;
            String affliateSubmissionTimeLineDays;
            String importComments;
            String version;
            String sequence;
            String excludePivotRule;
            String inclusionLogicJSON;
            String findTimeLineDueDateBasedOn;
            String trustedPartner;
            String mhlwReportType;
            String mhlwDeviceReportType;
            String mhlwRegenerativeReportType;
            String completeFlag;
            String locallyExpedited;
            String immediateReportFlag;
}
