package com.arisglobal.functiontest.utils;

import static com.arisglobal.functiontest.config.ServiceName.configFileReader;
import static com.arisglobal.functiontest.utils.TestUtils.getEnvOrDefault;

public class TestDataUtils {
    public static final String CREATE_RULE_BODY_PATH = "/payload/Request/Create_Rule_Body.json";
    public static final String SIMPLE_EXP_RULE_CONDITIONS_PATH = "/payload/Request/SimpleExpRuleConditions.json";
    public static final String NESTED_EXPRESSION_RULECONDITIONS_PATH = "/payload/Request/NestedExpRuleConditions.json";
    public static final String CREATE_RULE_RBODY_PATH = "/payload/Request/CreateRule.json";
    public static final String COPY_RULE_BODY_PATH = "/payload/Request/Copy_Rule_Body.json";
    public static final String RULES_RULEBUILDER_RESPONSE_PATH = "/payload/Response/GetAllRules_RuleBuilder.txt";
    public static final String RULES_SUPPORTED_LIBRARY_RESPONSE_PATH = "/payload/Response/GetAllSupportedLibrary.json";
  //============================ADMN-1058_GetConditionDisplayText
    public static final String CYCLIC_DEPENDENCY_REFERENCE_BODY_PATH = "/payload/Request/ConditionDisplayText/CyclicDependencyOfReferenceRule.json";
    public static final String CYCLIC_DEPENDENCY_RULECONDITION_BODY_PATH = "/payload/Request/ConditionDisplayText/CyclicDependencyOverRuleCondition.json";
    public static final String FILTER_RULECONDITION_BODY_PATH = "/payload/Request/ConditionDisplayText/FilterRuleCondition.json";
    public static final String REFRULE_RULECOND_PRIORITY_BODY_PATH = "/payload/Request/ConditionDisplayText/PriorityReferanceRuleAndRuleCondition.json";
    public static final String REFRULE_BODY_PATH = "/payload/Request/ConditionDisplayText/ReferenceRule.json";
    public static final String RULECOND_BODY_PATH = "/payload/Request/ConditionDisplayText/SimpleRuleCondition.json";

    //================================================SMQ_CMQ==========
    public static final String Response_All_SMQCMQLIB_PATH = "/payload/Response/SMQ_CMQLib/AllSMQ_CMQLib.json";
//    public static final String Response_CONTAINSO_SMQCMQLIB_PATH = "/payload/Response/SMQ_CMQLib/ContainsO_SMQ_CMQLib.json";
//    public static final String Response_STARTSWITHO_SMQCMQLIB_PATH = "/payload/Response/SMQ_CMQLib/StartsWithO_SMQ_CMQLib.json";
//    public static final String Response_ENDSWITHO__SMQCMQLIB_PATH = "/payload/Response/SMQ_CMQLib/EndsWithO_SMQ_CMQLib.json";
//    public static final String Response_STARTSWITH2_SMQCMQLIB_PATH = "/payload/Response/SMQ_CMQLib/StartsWith2_SMQ_CMQLib.json";

    //=====================================
    public static final String GET_TOKEN_BODY_PATH = "/payload/authentication/get_token_bdy.json";
    public static final String EMPTY_BODY = "/payload/Response/Empty.json";
    public static final String MODULES_FORMS = "/payload/Response/Modules&Forms.json";
    public static final String CONDITION_PATH = "/payload/Request/Condition.txt";
    public static final String GET_RULEDETAILS_PATH = "/payload/Request/Get_Rule_Body.json";
    public static final String GET_RULEDETAILS_AutoCALPATH = "/payload/Request/Get_Rule_Body_AutoCalculation.json";
    public static final String UPDATE_RULEDETAILS_PATH = "/payload/Request/UpdateRule_Bookmark_Body.json";
    public static final String GET_FILTERRULE_PATH = "/payload/Request/FilterRule_Body.json";
    public static final String GET_ANCHOR_PATH = "/payload/Request/AnchorBody.json";
    public static final String GET_ACTIONITEMS_PATH = "/payload/Request/ActionItems.json";
    public static final String GET_DATEUNIT_CONVERSION_PATH = "/payload/Request/DateUnitConversion.json";

    // public static final String EXPRESSION_PATH = "/payload/Request/Expression.json";

    public static final String SERVICE_URLL = getEnvOrDefault("SERVICE_URL", configFileReader.getProperty("environmentApi")+ "lsmv-admin-service/");
    public static final String GET_TOKEN_URLI = getEnvOrDefault("TOKEN_URL", "https://lggsdtqbjj.execute-api.eu-west-1.amazonaws.com/qc/token");
    public static final String LSMV_ADMIN_RULE_URL = SERVICE_URLL + "rule";
    public static final String LSMV_ADMIN_RULE_COPY_URL = LSMV_ADMIN_RULE_URL+"/copy";
    public static final String LSMV_ADMIN_RULE_ActivateOrDeactivate = LSMV_ADMIN_RULE_URL+"/activateOrInactivate?ruleId=%s&activateRule=%s";
    public static final String LSMV_ADMIN_RULE_UNIQUENESS = LSMV_ADMIN_RULE_URL+"/check";
    public static final String LSMV_ADMIN_RULES_RULEBUILDER = LSMV_ADMIN_RULE_URL+"/typelist";
    public static final String LSMV_ADMIN_LIBRARY_RULES = LSMV_ADMIN_RULE_URL+"/library";
    public static final String LSMV_ADMIN_EXPORT_INDIVISUAL_RULE = LSMV_ADMIN_RULE_URL+"/export";
    public static final String LSMV_ADMIN_FILTER_RULES = LSMV_ADMIN_RULE_URL+"/rules";
    public static final String LSMV_ADMIN_DISCONTACT_RULE = SERVICE_URLL+"distcontact/rule";
    public static final String LSMV_ADMIN_EXPRESSION_TEXT = LSMV_ADMIN_RULE_URL+"/expressiontext";
    public static final String LSMV_ADMIN_CONDITION_TEXT = LSMV_ADMIN_RULE_URL+"/conditiontext";
    public static final String LSMV_ADMIN_RULEDETAILS = LSMV_ADMIN_RULE_URL+"/rules";
    public static final String GET_ALLRULES_BODY_PATH = "/payload/Request/Get_All_Rules_Body.json";
    public static final String LSMV_ADMIN_RULE_FREEZE_URL = LSMV_ADMIN_RULE_URL+"/freeze";
    public static final String FREEZE_RULE_BODY_PATH = "/payload/Request/FreezeRule.json";
    public static final String LSMV_ADMIN_EXPORTRULE_URL = LSMV_ADMIN_RULE_URL+"/export";
    public static final String EXPORT_RULE_AsPDF_BODY_PATH = "/payload/Request/ExportRuleAsPDF.json";
    public static final String EXPORT_RULE_AsDAT_BODY_PATH = "/payload/Request/ExportRuleAsDAT.json";
    public static final String EXPORT_RULE_AsEXCEL_BODY_PATH = "/payload/Request/ExportRuleAsEXCEL.json";
    public static final String LSMV_ADMIN_EXPORTCONTACT_AsExcel_URL = SERVICE_URLL+"distcontact/export?isExcel=true&isDat=false";
    public static final String LSMV_ADMIN_EXPORTCONTACT_AsDat_URL = SERVICE_URLL+"distcontact/export?isExcel=false&isDat=true";
    public static final String EXPORT_CONTACT_BODY_PATH = "/payload/Request/ExportDistContact.json";

}