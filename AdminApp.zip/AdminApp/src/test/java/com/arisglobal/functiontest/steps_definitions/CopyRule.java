package com.arisglobal.functiontest.steps_definitions;

import com.arisglobal.functiontest.helper.ApiHelper;
import com.arisglobal.functiontest.helper.ApiHelperForNeg;
import com.arisglobal.functiontest.pojo.CreateRuleResponse;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import net.sf.json.JSONObject;
import net.sf.json.test.JSONAssert;

import java.util.logging.Logger;

import static com.arisglobal.functiontest.hooks.Hooks.scenarioContext;
import static com.arisglobal.functiontest.utils.TestDataUtils.*;
import static com.arisglobal.functiontest.utils.TestUtils.getFileContent;
import static net.sf.json.JSONObject.fromObject;
import static org.junit.Assert.assertEquals;

public class CopyRule {
    CreateRuleResponse ParentResponse;
    String ParentRuleID;
    String ChildRuleID;
    String childRuleRandomRule;
   final String randomPRule = CreateRule.randomRule;
    final String randomBRule = GetRulesByFilter.randomRule;

    @When("I copy parent rule {string} to new rule {string}")
    public void iCopyParentRuleToNewRule(String parentRuleID, String childRuleID) {
        ParentRuleID = randomPRule;
        ChildRuleID = CustomSteps.generateRandomRule();
        childRuleRandomRule= ChildRuleID;
        ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_RULE_COPY_URL, fromObject(getFileContent(COPY_RULE_BODY_PATH).replace("TestR9", ChildRuleID).replace("RuleAGXm", ParentRuleID)));
    }

    @When("I copy parent rule {string} to new rule {string} having Bookmarks")
    public void iCopyParentRuleToNewRuleBookmarks(String parentRuleID, String childRuleID) {
        ParentRuleID = randomBRule;
        ChildRuleID = CustomSteps.generateRandomRule();
        childRuleRandomRule= ChildRuleID;
        ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_RULE_COPY_URL, fromObject(getFileContent(COPY_RULE_BODY_PATH).replace("TestR9", ChildRuleID).replace("RuleAGXm", ParentRuleID)));
    }

    @When("I copy already existing rule")
    public void iCopyAlreadyExistingRule() {
        ParentRuleID = randomPRule;
        ChildRuleID=  randomPRule;
        ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_RULE_COPY_URL, fromObject(getFileContent(COPY_RULE_BODY_PATH).replace("TestR9", ChildRuleID).replace("RuleAGXm", ParentRuleID)));
    }

    @And("store the response of parent rule details")
    public void storeTheResponseOfGetRule() {
        Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        ParentResponse = response.as(CreateRuleResponse.class);
    }

    @And("compare the response with stored response of Parent")
    public void compareTheResponseWithStoredResponseOfParent() {
        Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        CreateRuleResponse childResponse = response.as(CreateRuleResponse.class);
//        assertEquals(ParentResponse.getRuleExpression(), childResponse.getRuleExpression());
//        assertEquals(ParentResponse.getRuleConditions(), childResponse.getRuleConditions());
//        assertEquals(ParentResponse.getConditionExpression(), childResponse.getConditionExpression());
//        assertEquals(ParentResponse.getModuleName(), childResponse.getModuleName());
//        //assertEquals(ParentResponse.getRuleID(), childResponse.getParentRuleId());
//        assertEquals(ParentResponse.getRuleFields(), childResponse.getRuleFields());
//        assertEquals(ParentResponse.getIsValid(), childResponse.getIsValid());
//        assertEquals(ParentResponse.getRuleOutcomes(), childResponse.getRuleOutcomes());
//        assertEquals(ParentResponse.getScriptedYN(), childResponse.getScriptedYN());
//        assertEquals(ParentResponse.getRuleScript(), childResponse.getRuleScript());
//        assertEquals(ParentResponse.getRuleParamMap(), childResponse.getRuleParamMap());
//        assertEquals(ParentResponse.getExculdableRule(), childResponse.getExculdableRule());
//
        JSONObject js = fromObject(getFileContent(COPY_RULE_BODY_PATH));
        String expectedRuleName = js.get("ruleName").toString();
        String expectedRuleDesc = js.get("ruleDescription").toString();
        String expectedRuleType = js.get("ruleType").toString();

        assertEquals(ChildRuleID, childResponse.getRuleID());
        assertEquals(expectedRuleName, childResponse.getRuleName());
        assertEquals(expectedRuleDesc, childResponse.getDescription());
        assertEquals(expectedRuleType, childResponse.getRuleType());
    }

    @When("I copy rule for invalid {string}")
    public void iCopyRuleForInvalid(String invalidField) {
        ApiHelperForNeg.sendPostRequestToAPIForInvalidType(LSMV_ADMIN_RULE_COPY_URL, fromObject(getFileContent(COPY_RULE_BODY_PATH)), invalidField);
    }
}
