package com.arisglobal.functiontest.steps_definitions;

import com.arisglobal.functiontest.helper.ApiHelper;
import com.arisglobal.functiontest.helper.ApiHelperForNeg;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import io.restassured.response.Response;

import static com.arisglobal.functiontest.hooks.Hooks.scenarioContext;
import static com.arisglobal.functiontest.utils.TestDataUtils.LSMV_ADMIN_RULE_UNIQUENESS;
import static org.junit.Assert.assertEquals;

public class GetRuleUniqueness {
    String randomURule =CreateRule.randomRule;
    @When("I get rule uniqueness of rule ID {string}")
    public void iGetRuleUniquenessOfRuleID(String ruleID) {
        if(ruleID.equals("RuleInvalid"))
            ApiHelper.sendGetRequestToApp(String.format(LSMV_ADMIN_RULE_UNIQUENESS + "/" + ruleID));
        else
            ApiHelper.sendGetRequestToApp(String.format(LSMV_ADMIN_RULE_UNIQUENESS + "/" + randomURule));
    }

    @And("get rule response contains {string}")
    public void getRuleResponseContains(String isUnique) {
        Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        String actualResponse = response.asString();
        assertEquals(isUnique,actualResponse);
    }

    @When("I get rule uniqueness of rule ID {string} for invalid {string}")
    public void iGetRuleUniquenessOfRuleIDForInvalid(String ruleID, String invalidField) {
        ApiHelperForNeg.sendGetRequestToAPIForInvalidType(String.format(LSMV_ADMIN_RULE_UNIQUENESS + "/" +ruleID), invalidField);
    }

    @When("I get rule uniqueness of empty rule ID")
    public void iGetRuleUniquenessOfEmptyRuleID() {
        ApiHelper.sendGetRequestToApp(LSMV_ADMIN_RULE_UNIQUENESS+ "/");
    }
}
