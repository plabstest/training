package com.arisglobal.functiontest.steps_definitions;

import com.arisglobal.functiontest.helper.ApiHelper;
import com.arisglobal.functiontest.helper.ApiHelperForNeg;
import com.arisglobal.functiontest.pojo.CreateRuleResponse;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import io.restassured.response.Response;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import static com.arisglobal.functiontest.hooks.Hooks.scenarioContext;
import static com.arisglobal.functiontest.utils.TestDataUtils.*;
import static com.arisglobal.functiontest.utils.TestUtils.getFileContent;
import static net.sf.json.JSONObject.fromObject;
import static org.junit.Assert.assertEquals;

public class GetRuleDetails {

    final String randomRule = CustomSteps.generateRandomRule();
    final String randomRulCreate = CreateRule.randomRule;
    @When("I get rule details by rule ID {string}")
    public void iGetRuleDetailsFromRuleID(String ruleID) {
         if(ruleID.equals("CreatedRule"))
            ruleID =  randomRulCreate;
        else if(ruleID.equals("invalidRule"))
             ruleID = "invalidRule";
            else ruleID = randomRule;
        ApiHelper.sendGetRequestToApp(String.format(LSMV_ADMIN_RULE_URL + "/" + ruleID));
    }

    @When("I get rule details by rule ID {string} for invalid {string}")
    public void GetRuleDetailsFromRuleIDForInvalid(String ruleID, String invalidField) {
        ApiHelperForNeg.sendGetRequestToAPIForInvalidType(String.format(LSMV_ADMIN_RULE_URL + "/" + randomRule), invalidField);
    }

    @And("get rule response contains rule with")
    public void getRuleNResponseContainsRuleWith(List<Map<String, String>> expectedDataTable) {
        Response response = (Response) scenarioContext.getScenarioVariables().get("RESPONSE");
        CreateRuleResponse getRulesResponse = response.as(CreateRuleResponse.class);
        String expectedRuleName = expectedDataTable.get(0).get("ruleName");
        String expectedRuleType = expectedDataTable.get(0).get("ruleType");
        String expectedRuleDesc = expectedDataTable.get(0).get("description");

        assertEquals(expectedRuleName, getRulesResponse.getRuleName());
        assertEquals(expectedRuleType, getRulesResponse.getRuleType());
        assertEquals(expectedRuleDesc, getRulesResponse.getDescription());
    }

    @When("I Export the Individual Rule of rule ID {string}")
    public void iExportTheIndividualRuleOfRuleID(String ruleID) {
        if(ruleID.equals("CreatedRule"))
            ruleID = randomRulCreate;
         ApiHelper.sendPostRequestWithHeadersToApp(LSMV_ADMIN_EXPORT_INDIVISUAL_RULE + "/" + ruleID, fromObject(getFileContent(EMPTY_BODY)));
         }

    @When("I Export the Individual Rule of ruleID {string} for invalid {string}")
    public void iExportTheIndividualRuleOfRuleIDForInvalid(String ruleID, String invalidField) {
        ApiHelperForNeg.sendPostRequestToAPIForInvalidType(LSMV_ADMIN_EXPORT_INDIVISUAL_RULE + "/" + randomRule, fromObject(getFileContent(EMPTY_BODY)), invalidField);
    }

    @When("I validate response data with {string} for field {string} as {string}")
    public void iValidateJSONResponse(String ruleID, String field, String value) throws IOException {
        String new_value;
        if(ruleID.equals("CreatedRule"))
            ruleID =  randomRulCreate;
        Response res = ApiHelper.sendGetRequest(String.format(LSMV_ADMIN_RULE_URL + "/" + ruleID));
        if(value.contains("summary")) {
             new_value = value + ruleID;
        }
        else new_value=value;
        Utils.validateJSON(res, ruleID, field, new_value);
    }
}
